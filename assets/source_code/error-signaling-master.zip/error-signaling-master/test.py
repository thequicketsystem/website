import error_signaling

test = error_signaling.ErrorSignaler()

test.error()
