# error-signaling
basic wrappers for signaling error status on The Quicket System's LED strip
