# pi-setup
This cannot be considered a safe or clean script, *please* read it before execution.