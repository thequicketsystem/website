# people-counting-visual
Fallback people counting subsystem that uses visual images rather than thermal

Largely uses code from [this article](https://www.pyimagesearch.com/2018/08/13/opencv-people-counter/).